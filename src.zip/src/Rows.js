import React, { Component } from 'react';
import './Rows.css';
import Cell from './Cell';

class Rows extends Component {
  render() {
    return (
      <div className={`${this.props.className}`}>
        {this.props.children}
      </div>
    );
  }
}

export default Rows;

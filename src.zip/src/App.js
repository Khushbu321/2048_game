import React, { Component } from 'react';
import './App.css';
import Rows from './Rows';
import Cell from './Cell';

class App extends Component {
  constructor(props){
    super(props);
    const arr = [[2,0,0,0,0],[2,0,0,0,0],[4,0,0,0,0],[4,0,0,0,0],[0,0,0,0,0]];
    this.state = {
        randomNoGenerated: true,
        arr : arr
    }
}

componentDidMount = () => {
    let arr = this.state.arr;
    const obj = this.getRowColumn();
    const obj2 = this.getRowColumn();
    arr[obj.row][obj.col] = 2;
    arr[obj2.row][obj2.col] = 2;
    this.setState({
      arr : arr
    });
    document.addEventListener('keydown', this.getKeyPressed);
  }
  
  componentWillUnmount = () => {
    document.removeEventListener('keydown', this.getKeyPressed);
  }


getRowColumn = () => {
  const obj = {};
  let arr = this.state.arr;
  let row =  Math.floor(Math.random() * Math.floor(5));
  let col =  Math.floor(Math.random() * Math.floor(5));
  if(arr[row][col] !== 0){
    return this.getRowColumn();
  }
  obj.row = row;
  obj.col = col;
  return obj;
}

getKeyPressed = (e) => {
  if(e.keyCode === 37){
    this.moveLeft();
  }
  else if(e.keyCode === 38){
    this.moveUp();
  }
  else if(e.keyCode === 39){
    this.moveRight();
  }
  else{
    this.moveDown();
  }
}

moveLeft = () => {
  var arr = this.state.arr;
  var res = [[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]];
   for(var i = 0 ; i < 5; i++){
     for(var j = 0 ; j < 5; j = j + 1){
       if(arr[i][j] === arr[i][j+1]){
        res[i][j] = arr[i][j] + arr[i][j+1];
        j = j + 1;     
       }
     }
   }
   console.log(res);
  }

moveUp = () => {
  var arr = this.state.arr;
  var res = [[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]];
   for(var i = 4 ; i > 0; i--){
     for(var j = 4 ; j > 0; j--){
        res[0][i] = arr[j][i] + res[0][i];
     }
   }
   console.log(res);
}

moveRight = () => {
  var arr = this.state.arr;
  var res = [[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]];
   for(var i = 0 ; i < 4 ; i++){
     for(var j = 0 ; j < 4 ; j++){
        res[i][4] = arr[i][j] + res[i][4];
     }
   }
   console.log(res);  
}

moveDown = () => {
  var arr = this.state.arr;
  var res = [[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]];
  for(var i = 0 ; i < 4 ; i++){
    for(var j = 0 ; j < 4 ; j++){
       res[4][i] = arr[j][i] + res[4][i];
    }
  }
  console.log(res);
}

renderCells(row, rowIndex) {
  return (
    row.map((cell, cellIndex) => <Cell key={`${rowIndex}-${cellIndex}`} className="Cell">{cell}</Cell>)
  );
}

renderRows() {
    return this.state.arr.map((row, rowIndex) => {
      return (
        <Rows className = "Rows" key={rowIndex}>
            {this.renderCells(row, rowIndex)}
        </Rows>
      )
    })
  }

render() {
  return (
    <div className="App">
    <div className ="table">
    {this.renderRows()}
    </div>
    </div>
  );
}
}


export default App;
